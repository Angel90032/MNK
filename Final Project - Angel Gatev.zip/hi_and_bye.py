""" contains the implementation of the say_hello and say_goodbye functions, pretty self-explanatory really... ;]"""

def say_hello() -> str:
    return "Welcome to Task Management System version 1.00 !\n "


def say_goodbye() -> str:
    return "Have a nice day!"
